/*
CommandSystem.java
For use in the Final project for COSC 236.
Based on starter code first developed by Prof. Dastyni Loksa

This class is the primary logic class for the system. It defines what commands are valid, 
and what happens when those commands are executed.  
*/

import java.util.*;
import java.util.Random;

public class CommandSystem {
    private static int DISPLAY_WIDTH;
    private GameState state;
    private Item item;

    Random rand = new Random();

    private List<String> verbs = new ArrayList<String>();
    private List<String> verbDescription = new ArrayList<String>();
    private List<String> nouns = new ArrayList<String>();

    /*
     * Constructor should defines all verbs that can be used in the commands and all
     * nouns the user can interact with.
     * 
     * Suggestion: These could all be loaded from a file.
     * 
     * Verb descriptions are stored in a parallel Arraylist with the Verbs and are
     * used when printing out the help menu (using the ? command).
     */
    public CommandSystem(GameState state) {
        this.state = state;
        DISPLAY_WIDTH = GameState.DISPLAY_WIDTH;
        // Assign verbs and descriptions here
        addVerb("?", "Show this help screen.");
        addVerb("look",
                "Use the look command by itself to look in your current area. \nYou can also look at a person or object by ntyping look and the name of what you want to look at.\nExample: look book");
        addVerb("l", "Same as the look command.");

        addVerb("n", "Move north.");
        addVerb("north", "same as the n command");

        addVerb("move north", "Move north");

        addVerb("s", "Move south.");
        addVerb("south", "same as the s command");

        addVerb("e", "Move east.");
        addVerb("east", "same as the e command");

        addVerb("w", "Move west.");
        addVerb("west", "same as the w command");

        addVerb("pick", "Pickup item.");
        addVerb("p", "same as the p command");

        addVerb("a", "attack the person");
        addVerb("attack", "same as the a command");

        addVerb("i", "Open inventory.");

        addVerb("dw", "Drink water.");
    
        addVerb("scare", " Scare the enemy ");

        addVerb("yell", "Yell at the enemy");


        addVerb("down", " You look down ");
        addVerb("look down", "Same as the down command");

        addVerb("quit", "Quit the game."); // NOTE: In the starter code, this is handeled by the client code - not the
                                           // CommandSystem.
    }

    // When a command is only one Verb this method controls the result.
    public void executeVerb(String verb) {
        String resultString = "";

        switch (verb) {
            case "l":
            case "look": // will show the description of the current room (stored in the state object)
                System.out.println("You look around.");
                System.out.println(formatStringToScreenWidth(state.currentLocation.description));
                if(state.currentLocation.animalHere != null){
                    System.out.println(formatStringToScreenWidth(state.currentLocation.animalHere.description));
                }
                break;
            case "?":
                this.printHelp();
                break;
            case "n":
            case "north":
            case "move north":
                System.out.println(" You move North");
                if (state.currentLocation.north == null) {
                    System.out.println("You can't go there from here.");
                    return;
                }
                state.currentLocation = state.currentLocation.north;
                // resultString = "You move north to the "+state.currentLocation.name;
                resultString += "[nl]" + state.currentLocation.description;
                if(state.currentLocation.animalHere != null)
                resultString += "[nl]" + state.currentLocation.animalHere.description;
                break;

            case "s":
            case "south":
                System.out.println(" You move to the South");
                if (state.currentLocation.south == null) {
                    System.out.println("You can't go there from here.");
                    return;
                }
                state.currentLocation = state.currentLocation.south;
                resultString += "[n1]" + state.currentLocation.description;
                if(state.currentLocation.animalHere != null)
                resultString += "[nl]" + state.currentLocation.animalHere.description;
                break;

            case "e":
            case "east":
                System.out.println(" You move towards the East");
                if (state.currentLocation.east == null) {
                    System.out.println("You can't go there from here.");
                    return;
                }
                state.currentLocation = state.currentLocation.east;
                resultString += "[n1]" + state.currentLocation.description;
                if(state.currentLocation.animalHere != null)
                resultString += "[nl]" + state.currentLocation.animalHere.description;
                break;

            case "w":
            case "west":
                System.out.println(" You move to the west");
                if (state.currentLocation.west == null) {
                    System.out.println("You can't go there from here.");
                    return;
                }
                state.currentLocation = state.currentLocation.west;
                resultString += "[n1]" + state.currentLocation.description;
                if(state.currentLocation.animalHere != null)
                resultString += "[nl]" + state.currentLocation.animalHere.description;
                break;

            case "a":
            case "attack":
                if(state.currentLocation.animalHere != null){
                    while(state.currentLocation.animalHere.health > 0){
                    System.out.println(" Your enemy Hp is " + state.currentLocation.animalHere.health);
                    state.currentLocation.animalHere.health-=state.human.attackDamage;
                    state.human.playerhealth -=state.currentLocation.animalHere.animalAttackDamage;
                System.out.println("You attack the " + state.currentLocation.animalHere.name + " for an amount of " + state.human.attackDamage + " The enemy health is now " + state.currentLocation.animalHere.health);
                System.out.println("-------------------------------------------");
                System.out.println(" The " + state.currentLocation.animalHere.name + " attacked you for an amount of " + state.currentLocation.animalHere.animalAttackDamage + " your health now is " + state.human.playerhealth);
                if(state.human.playerhealth<=0){
                    System.out.println(" You have been defeated by the " + state.currentLocation.animalHere.name);
                    System.out.println(" You have been succumbed by the animal kindgom riot ");
                    break;
                }
                if(state.currentLocation.animalHere.health < 0){
                    System.out.println(" You have defeated the " + state.currentLocation.animalHere.name);
                    System.out.println(" You have " + state.human.playerhealth + " Hp: left " );
                    break;
                }
                break;

            } 
        }
               else System.out.println(" You attack the " + state.currentLocation.name + " Which is air ");
                System.out.println(formatStringToScreenWidth(state.currentLocation.description));
                break;

            case "pick":
            case "p":
            if (state.currentLocation.itemHere != null)
                    System.out.println(" You picked up the " + state.currentLocation.itemHere.name + " And store it in your inventory");
                break;

            case "i":
            case "inventory":
                System.out.println(" You've open your inventory, in your inventory you have" + state.currentLocation.itemHere.name + " ");
                break;

            case "dw":
            case "drinkwater":
                if (state.currentLocation.description == state.river.description
                        && state.currentLocation.name == state.river.name)
                        state.human.playerhealth += 3;
                    System.out.println( " You drink some water from the" + state.river.name + ", reganing " +state.human.playerhealth + " amount of health");
                if (state.currentLocation.name != state.river.description
                        && state.currentLocation.name != state.river.name)
                    System.out.println(" There no water in this area!! ");
                break;

            case "down":
                if (state.currentLocation.itemHere != null) {
                    System.out.println(" You look down and noticed " + state.currentLocation.itemHere.name  + " On the ground ");
                    System.out.println("---------------------------------------");
                }
                break;

            case "yell":
            case "scare":
            if(state.currentLocation.animalHere != null){
             System.out.println("You tried yelling at the " + state.currentLocation.animalHere.name + " to no advil ");
            if(state.currentLocation.animalHere.name == state.forest.animalHere.name){
            state.human.playerhealth -=state.currentLocation.animalHere.animalAttackDamage;
             System.out.println(" The" + state.forest.animalHere.name + " saw you as the threat and attack you ,you now have " + state.human.playerhealth + " health left ");     
            } 


            }
                else System.out.println(" You tried yelling at the " + state.currentLocation.name + " Which is air?? ");
                System.out.println(formatStringToScreenWidth(state.currentLocation.description));
                break;

        }

        System.out.println(formatStringToScreenWidth(resultString));
    }

    // When a command is a Verb followed by a noun, this method controls the result.
    public void executeVerbNoun(String verb, String noun) {
        // Initilize the string that we will use as a response to player input.
        String resultString = "";

        switch (verb) { // Deciddes what to do based on each verb
            case "l":
            case "look":
                resultString = lookAt(noun);

            case "look down":
                resultString = lookAt(state.currentLocation.itemHere.name);

            case "stare":
            resultString = lookAt(" The " + state.currentLocation.animalHere.name + ", grows closer ");

            case "a":
            case "attack":
                resultString = " ";

            case "dw":
            case "drinkwater":
                resultString = " ";

                case "yell":
                case "scare":
                resultString = " ";    
        }

        System.out.println(formatStringToScreenWidth(resultString));
    }

    // When a command is a Verb followed by two nouns, this method controls the
    // result.
    public void executeVerbNounNoun(String string, String string2, String string3) {

    }

    // Method to take care of looking at a noun.
     
    public String lookAt(String noun) {
        // This will be what is returned by the method.
        String resultString = "";

        switch (noun) { // for the given verb, decide what to do based on what noun was entered
            case "mat":
                // get the description from the item you are looking at.
                resultString += state.mat.description;
                break;

            case "pocketknife":
                resultString += state.knife.description;
                break;

            case "sticks":
                resultString += state.sticks.description;
                break;

            case "mushrooms":
                resultString += state.mushrooms.description;
                break;

            case "berries":
                resultString += state.berries.description;
                break;

            case "bushes":
                resultString += state.bushes.description;
                break;

            case "bear":
            resultString += state.currentLocation.animalHere.description;
            break;


            // You cound design a way to look at any item without having to specify how to
            // deal with each of them.
            // That way you can code special cases for some items, and others would just use
            // default behavior.
            // This is HIGHLY encouraged. (It will save time and headaches!)
            default:
        }
        return resultString;
    }

    /*****************************************************************
     * Helper methods to help system work.
     ******************************************************************/

    /*
     * Prints out the help menu. Goes through all verbs and verbDescriptions
     * printing a list of all commands the user can use.
     */
    public void printHelp() {
        String s1 = "";
        while (s1.length() < DISPLAY_WIDTH)
            s1 += "-";

        String s2 = "";
        while (s2.length() < DISPLAY_WIDTH) {
            if (s2.length() == (DISPLAY_WIDTH / 2 - 10)) {
                s2 += " Commands ";
            } else {
                s2 += " ";
            }
        }

        System.out.println("\n\n" + s1 + "\n" + s2 + "\n" + s1 + "\n");
        for (String v : verbs) {
            // System.out.printp(v + " --> " + verbDescription.get(verbs.indexOf(v)));
            System.out.printf("%-8s  %s", v, formatMenuString(verbDescription.get(verbs.indexOf(v))));
        }
    }

    // Allows the client code to check to see if a verb is in the game.
    public boolean hasVerb(String string) {
        return verbs.contains(string);
    }

    // Allows the client code to check to see if a noun is in the game.
    public boolean hasNoun(String string) {
        return nouns.contains(string);
    }

    // Used to format the help menu
    public String formatMenuString(String longString) {
        String result = "";
        Scanner chop = new Scanner(longString);
        int charLength = 0;

        while (chop.hasNext()) {
            String next = chop.next();
            charLength += next.length();
            result += next + " ";
            if (charLength >= (DISPLAY_WIDTH - 30)) {
                result += "\n          ";
                charLength = 0;
            }
        }
        chop.close();
        return result + "\n\n";
    }

    // formats a string to DISPLAY_WIDTH character width.
    // Used when getting descriptions from items/locations and printing them to the
    // screen.
    // use [nl] for a newline in a string in a description etc.
    public String formatStringToScreenWidth(String longString) {

        Scanner chop = new Scanner(longString);
        String result = "";
        int charLength = 0;
        boolean addSpace = true;

        while (chop.hasNext()) {

            // Get our next word in the string.
            String next = chop.next();

            // Add the legnth to our charLength.
            charLength += next.length() + 1;

            // Find and replace any special newline characters [nl] with \n.
            if (next.contains("[nl]")) {
                // Find the index after our [nl] characters.
                int secondHalf = next.indexOf("[nl]") + 4;

                // Set charLength to the number of characters after the [nl],
                // because that will be the beginnig of a new line.
                if (secondHalf < next.length()) {
                    charLength = secondHalf;
                } else {
                    charLength = 0;
                    addSpace = false; // Do not add space after if this ended with a newline character.
                }

                // Now actually replace the [nl] with the newline character
                next = next.replace("[nl]", "\n");

            }

            // Add the word to the result.
            result += next;

            // Only add a space if our special case did not happen.
            if (addSpace)
                result += " ";

            // Normally we add a space after a word, prepare for that.
            addSpace = true;

            if (charLength >= DISPLAY_WIDTH) {
                result += "\n";
                charLength = 0;
            }
        }
        chop.close();
        return result;
    }

    // Adds a noun to the noun list
    // lets the command system know this is something you an interact with.
    public void addNoun(String string) {
        if (!nouns.contains(string.toLowerCase()))
            nouns.add(string.toLowerCase());
    }

    // Adds a verb to the verb list and the description to the parallel description
    // list
    // Adding a verb lets the command system know you want this to be a command.
    public void addVerb(String verb, String description) {
        verbs.add(verb.toLowerCase());
        verbDescription.add(description.toLowerCase());
    }

}
